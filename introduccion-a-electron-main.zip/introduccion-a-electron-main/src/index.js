
// Importación de módulos
const { app, BrowserWindow } = require('electron');
const path = require('path');

// Esto maneja la creación / eliminación de accesos directos en Windows al instalar / desinstalar.
if (require('electron-squirrel-startup')) {
  app.quit();
}

const createWindow = () => {
  // Crea la ventana del navegador.
  const mainWindow = new BrowserWindow({
    width: 800,
    height: 600
  });

  // Carga el archivo index.html de la aplicación.
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
};

// Este método se ejecutará cuando Electron haya terminado
// la inicialización y esté listo para crear ventanas del navegador.
app.on('ready', createWindow);

// Salga cuando todas las ventanas estén cerradas.
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Resto de la aplicación
