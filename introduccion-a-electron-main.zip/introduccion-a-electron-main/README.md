
# Introducción a electron

Electron es un framework para crear aplicaciones de escritorio multiplataforma con tecnologías web. Está basado en Node.js y Chromium y es usado por empresas como GitHub, Microsoft y Slack.

## ¿Por qué usar Electron?

- Es rápido para desarrollar
- Es multiplataforma
- Es fácil de usar

# Instalación

Primer asegurarse de tener instalado Node.js y npm.

```bash
node -v
npm -v
```

Luego, clonar el repositorio actual, haciendo uso del siguiente comando:

```bash
git clone https://git.mora.tk/hros/introduccion-a-electron.git
```

Finalmente, instalar las dependencias del proyecto:

```bash
npm install
```

# Ejecución

Para ejecutar la aplicación, se debe ejecutar el siguiente comando:

```bash
npm start
```

Listo, ya puedes usar la aplicación.

# ¿Qué queda por aprender?
- Desarrollo de tecnologías web (HTML, CSS, JavaScript) para simplificar el desarrollo de aplicaciones de escritorio.
- Investigación sobre conversiones de bases numéricas.

# Consultas

Para consultas, puedes contactarme a través de WhatsApp al número 63505722 o Telegram al usuario @hros19.
